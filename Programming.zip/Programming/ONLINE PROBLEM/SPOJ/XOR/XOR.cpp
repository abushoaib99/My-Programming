#include<bits/stdc++.h>
using namespace std;
int main()
{
    bool x,y,c;
    cin>>x>>y;
    c=x^y;
    cout<<c<<endl;
    return 0;
}
