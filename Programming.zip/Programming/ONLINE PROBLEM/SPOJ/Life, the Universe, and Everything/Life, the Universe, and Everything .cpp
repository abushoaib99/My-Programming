#include<bits/stdc++.h>
int main()
{
    unsigned long long  n;
    while(scanf("%llu",&n)&& n!=42)
    {
        printf("%llu\n",n);
    }
    return 0;
}
