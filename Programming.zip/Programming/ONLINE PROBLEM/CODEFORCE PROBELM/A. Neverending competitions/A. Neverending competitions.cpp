#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,t;
    cin>>n;
    string s,s1;
    cin>>s;
    for(int i=1;i<=n;i++)
    {
        cin>>s1;
    }
    n%2==0 ? printf("home\n") : printf("contest\n");
    return 0;
}
