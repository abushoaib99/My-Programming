#include<bits/stdc++.h>
int	main()
{
	char ch[1001];
	gets(ch);
	ch[0]=toupper(ch[0]);
	printf("%s",ch);
}
