#include<bits/stdc++.h>
int main()
{
    int a;
    scanf("%d",&a);
    printf("%d\n",a+1);
    return 0;
}
