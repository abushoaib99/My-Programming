#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s,s1;
    cin>>s>>s1;
    reverse(s1.begin(),s1.end());
    s==s1 ? printf("YES\n") : printf("NO\n");
    return 0;
}
