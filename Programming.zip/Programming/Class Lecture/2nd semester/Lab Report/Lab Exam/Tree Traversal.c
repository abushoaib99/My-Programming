#include<stdio.h>
typedef struct node
{
    int info;
    struct node *left;
    struct node *right;
}list;


