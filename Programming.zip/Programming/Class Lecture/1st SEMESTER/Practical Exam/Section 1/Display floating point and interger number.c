#include<stdio.h>
int main()

{
    float a;
    int b;
    printf("Enter number: ");
    scanf("%f",&a);
    b=a;
    printf("Integer number = %d\n",b);
    printf("Floating number = %f\n",a-b);
    return 0;
}
