#include <stdio.h>
int main()
{
    int ara[5] = {10, 20, 30, 40, 50};
    printf("First element: %d\n", ara[0]);
    printf("Third element: %d\n", ara[2]);
    return 0;
}
