#include<stdio.h>
int main()

{
    int ara[5]={6,7,4,6,9};
    printf("%d\n",ara[-1]);
    printf("%d\n",ara[5]);
    printf("%d\n",ara[100]);
    return 0;
}
