#include<stdio.h>
int main()

{
    char line[5000];
    gets(line);
    printf("%s",line);
    return 0;
}
