#include<stdio.h>
int main()

{
    char name[10];
    printf("Enter your Name: ");
    scanf("%s",name);
    printf("\nYour name is: %s\n",name);
    return 0;
}
