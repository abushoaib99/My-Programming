#include<stdio.h>
int main()

{
    int ln;
    char s[15];
    printf("Enter Character: ");
    scanf("%s",s);
    ln=strlen(s);
    printf("\nLength of Character: %d\n",ln);
    return 0;
}
