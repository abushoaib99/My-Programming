#include<stdio.h>
void add()
    {
        int x,y;
        scanf("%d %d",&x,&y);
        printf("%d\n",x+y);
    }
    int main()
    {
        add();
        return 0;
    }


