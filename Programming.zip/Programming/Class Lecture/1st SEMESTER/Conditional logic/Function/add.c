#include <stdio.h>
int add(int num1,int num2)

{
    printf("The sum is\n");
    int sum=num1+num2;
    return sum;
}
int main()
{
        int a=2,b=2,c;
        c = add(a,b);
        printf("The sum is\n%d\n", c);
        return 0;
}
