#include<stdio.h>
int main()

{
    int n,row,col;
    printf("Number of Rows to be printed\n");
    scanf("%d",&n);
    for(row=1;row<=n;row++){
        for(col=1;col<=n-row;col++){  /*n=input value*/
            printf(" ");
        }
        for(col=1;col<=2*row-1;col++){
            printf("*");
        }
        printf("\n");
        }
        for(row=n-1;row>=1;row--){
        for(col=1;col<=n-row;col++){  /*n=input value*/
            printf(" ");
            }
            for(col=1;col<=2*row-1;col++){
            printf("*");
        }
        printf("\n");
        }

    return 0;
}



