#include<stdio.h>
int main()

{
    int i=1;
    char ch;
    while(i<=3){
    ch=getchar();
    printf("\n%c",ch);
    i++;
    }
    return 0;
}
