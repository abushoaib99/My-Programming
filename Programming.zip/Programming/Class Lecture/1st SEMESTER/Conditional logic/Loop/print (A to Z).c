#include<stdio.h>
int main()

{
    int i;
    for(i=65;i<=90;i++){
            printf("%c",i);

    }

    return 0;
}
