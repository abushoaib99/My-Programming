#include<stdio.h>
int main()

{
    int a,b,c,n,i;

    scanf("%d",&n);
    for(i=1;i<=n;i++){
    scanf("%d %d %d",&a,&b,&c);
    if(a>b && a>c)
        printf("case %d: %d\n",i,a);
    else if(b>a && b>c)
        printf("%d\n\n",b);
    else if(c>a && c>b)
        printf("case %d: %d\n",i,c);
        else if(a==b && a==c && b==c)
            printf("case %d: %d\n",i,a);
            else if(a==b && a>c)
                printf("case %d: %d\n",i,a);
                else if(a==b && a<c)
                printf("case %d: %d\n",i,c);
            else if(b==c && a>b)
                printf("case %d: %d\n",i,a);
            else if(b==c && a<b)
                printf("case %d: %d\n",i,b);
                    else if(a==c && b>c)
                    printf("case %d: %d\n",i,b);
                    else if(a==c && b<c)
                    printf("case %d: %d\n",i,c);

        }
        return 0;
}
