#include<stdio.h>
int main()

{
    char input;
    scanf("%c",&input);
    printf("\n%c\n",input+32);
    return 0;
}

