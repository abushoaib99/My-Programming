#include<iostream>
using namespace std;

int main()
{
    string a,b;
    cin>>a>>b;
    cout<<a+b;
    return 0;
}
