#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("input.txt","w",stdout);
    for(int i=1;i<=100000;++i)
    {
        printf("%d\n",rand());
    }
}
