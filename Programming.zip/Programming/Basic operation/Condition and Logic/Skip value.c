#include<stdio.h>
int main()

{
    int a,b,c;
    scanf("%d %d *%d",&a,&b,&c);
    printf("\n%d %d %d\n",a,b,c);
    scanf("%d %d",&a,&b);
    printf("\n%d %d\n",a,b);
    scanf("%d",&c);
    printf("\n%d\n",c);
    return 0;
}

