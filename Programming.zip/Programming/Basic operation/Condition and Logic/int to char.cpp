#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a;
    cin>>a;
    char ch[10];
    itoa(a,ch,10);
    printf("%s",ch);
}
