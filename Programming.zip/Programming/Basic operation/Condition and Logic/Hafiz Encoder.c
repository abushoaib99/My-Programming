#include <stdio.h>

int main(){
int i;
for(i=0;i<256;i++){
printf("CHARACTER :%c\tASCII: %d\tOCTAL: %o\tHEXA: %x\n",i,i,i,i);
}

return 0;
}
