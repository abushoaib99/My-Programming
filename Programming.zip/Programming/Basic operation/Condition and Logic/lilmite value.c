#include<stdio.h>
int main()

{
    int a,b;
    scanf("%3d",&a);
    printf("%d",a);
    scanf("%d",&b);
    printf("\n%d\n",b);
    return 0;
}
