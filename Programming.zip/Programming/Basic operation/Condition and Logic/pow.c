#include<stdio.h>
int main()

{
    int x,a;
    printf("input the value: ");
    scanf("%d",&a);
    x=pow(a,4);
    printf("the equation is %d:",x);
    return 0;
}
